# 1. Declare a div() function with two parameters. Then call the function and pass two numbers and display their division.

def div(a, b):
   return a / b

num1 = int(input("Enter the dividend\n"))
num2 = int(input("Enter the divisor\n"))

if num2 == 0 :
   print("Invalid divisor entered\n")
else :
   print(f"The quotient of {num1} and {num2} is ", div(num1, num2))