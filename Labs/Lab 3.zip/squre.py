
#  2. Declare a square() function with one parameter.Then call the function and pass one number and display the square of that number 

def square(a):
    return a * a

num = int(input("Enter a number to find out the squre\n"))
print(f"The squre of {num} is ", square(num))