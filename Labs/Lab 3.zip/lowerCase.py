
#  4. Accept a namefromthe user and display that in lower case using lower() function

name = input("Enter a name to print it in a lower case string\n")

print(name, "=>", name.lower())