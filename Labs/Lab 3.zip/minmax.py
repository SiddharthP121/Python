
#  3. Using max() and min() functions display the maximum and minimum of 5 random numbers.

numList = [ 23, 56, 87, 98, 113 ]

print(f"The maximum in {numList} is ", max(numList))
print(f"The minimum in {numList} is ", min(numList))




