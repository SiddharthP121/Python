
#  5. Write a lambda function that takes one argument and returns 'Positive' if the number is greater than 0, 'Negative' if it's less than 0, and 'Zero' if it's 0. Test it with different numbers.

is_Positive = lambda a: "Positive" if a > 0 else "Negative" if a < 0 else "Zero"

num = int(input("Enter a number to check if it is positive\n"))
print(f"{num} is", is_Positive(num))