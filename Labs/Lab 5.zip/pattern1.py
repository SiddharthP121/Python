'''
1.
    *
   * *
  *   *
 *     *
*       *
 *     *
  *   *
   * *
    *

'''

for i in range(1, 7):
    for spaces in range(6-i):
        print(" ", end="")
    for j in range(1, i):
        if j == 1 or i - 1 == j :
            print("*", end=" ")
        else:
            print(" ", end=" ")
    print()
for i in range(5, 1, -1):
    for spaces in range(6 - i):
        print(" ", end="")
    for j in range(1, i):
        if j == 1 or i - 1 == j :
            print("*", end=" ")
        else:
            print(" ", end=" ")
    print()


# another pattern

for i in range(1, 7):
    print(" " * (6-i), "* " * i)
for i in range(5, 0, -1):
    print(" " * (6-i), "* " * i)

