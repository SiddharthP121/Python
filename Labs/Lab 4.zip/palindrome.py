#  2. Write a python program to check whether a number is palindrome or not?

num = int(input("Enter the number to check wether it is a palindrome or not:\n"))

orginal_num = num
reversed_num = 0

while num > 0:
    digit = num % 10
    reversed_num = reversed_num * 10 + digit
    num = num // 10

if reversed_num == orginal_num:
    print("The number is a palindrome\n")
else: 
    print("The number is not a palindrome\n")