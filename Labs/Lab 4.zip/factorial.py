num = int(input("Enter the number you want the factorial of\n"))
factorial = 1
while num > 0:
   factorial = factorial * num
   num = num - 1

print(f"The factorial of ${num} is ", factorial)