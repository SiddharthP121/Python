#  4. Accept numbers using input() function until the user enters 0. If user input 0 then break the while loop and display the sum of all the numbers

num = int(input("Enter any number: \n"))
sum = 0

while num > 0:
    if num == 0:
        break
    else: 
        sum = sum + num
        num = int(input("Enter any number: \n"))

print("The sum of the numbers are", sum)
