'''
 Lab 3: Restaurant Menu Management
Scenario:
 You are helping a restaurant manage its menu. The restaurant has a regular menu and
 a special weekend menu.
 Tasks:
 1. Create a set regular_menu with items 'pizza', 'burger', 'salad', and 'pasta'.
 2. Create another set weekend_menu with items 'steak', 'salmon', 'pasta', and
 'wine'.
 3. Find out which items are available on both the regular and weekend menus.
 4. Determine the items that are only available on the weekend.
 5. Add a new item 'dessert' to both menus.
 6. The restaurant decides to stop offering 'burger'. Remove it from the regular
 menu

'''

regular_menu = {'pizza', 'burger', 'salad', 'pasta'}
weekend_menu = {'steak', 'salmon', 'pasta', 'wine'}

common_items = regular_menu.intersection(weekend_menu)
print('Common itmes in menus ->', common_items)

weekend_items = weekend_menu.difference(regular_menu)
print('Only weekend items ->', weekend_items)

dessert = ['Gulabjamun', 'Rasgulla']

regular_menu.add(dessert[0])
weekend_menu.add(dessert[1])

print('Added desert to both the menus')
print(regular_menu)
print(weekend_menu)

print('Removing burger')
regular_menu.discard('burger')
print(regular_menu)