'''
 Lab 2: Student Enrollment System
 Scenario:
 You are developing a student enrollment system for a university. The university offers
 courses in different subjects, and some students are enrolled in multiple courses.
 Tasks:
 1. Create a set course_A containing students 'Alice', 'Bob', 'Charlie'.
 2. Create another set course_B containing students 'Charlie', 'David', 'Eva'.
 3. Find out which students are enrolled in both course_A and course_B.
 4. List all students who are enrolled in either course_A or course_B.
 5. Identify students who are enrolled in course_A but not in course_B.
 6. Determine the students who are enrolled in only one course.
 
'''

course_A = {'Alice', 'Bob', 'Charlie'}
course_B = {'David', 'Eva', 'Charlie'}

print(f'Students of course A -> {course_A}')
print(f'Students of course B -> {course_B}')


common_student = course_A.intersection(course_B)
print(f'Common students in both courses -> {common_student}')

all_students = course_A.union(course_B)
print(f'All students courses -> {all_students}')

only_A = course_A.difference(course_B)
print(f'Students only in course A -> {only_A}')

only_one = course_A.symmetric_difference(course_B)
print(f'Students opt for only one course -> {only_one}')



