'''
 Lab 5: Healthcare Appointment Management
 Scenario:
 You are building a healthcare appointment system where patients can have either
 scheduled or walk-in appointments.
 Tasks:
 1. Create a set scheduled_appointments with patient names 'Anna', 'Bob', and
 'Clara'.
 2. Create another set walk_in_appointments with patient names 'Clara', 'David', and
 'Eva'.
 3. Identify patients who have both scheduled and walk-in appointments.
 4. List all patients who have any type of appointment.
 5. Determine which patients have only walk-in appointments.
 6. Add a new patient 'Frank' to the walk-in appointments and remove 'Eva' from
 scheduled appointments (if present).

'''

scheduled_appointments = {'Anna', 'Bob', 'Clara'}
walk_in_appointments = {'Clara', 'David', 'Eva'}

print('Patients with both appointment ->', *scheduled_appointments.intersection(walk_in_appointments))
print('Patients with any appointment ->', ', '.join(scheduled_appointments.union(walk_in_appointments)))
print('Patients with only walk in appointment ->', ', '.join(walk_in_appointments.difference(scheduled_appointments)))
walk_in_appointments.add('Frank')
print('Adding Frank to walk in appointments', ', '.join(walk_in_appointments))
scheduled_appointments.discard('Eva')
print('Removing Eva from scheduled appointments if present ->', ', '.join(scheduled_appointments))


