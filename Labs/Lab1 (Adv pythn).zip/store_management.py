'''
 Lab 1: Managing an Online Store Inventory
 Scenario:
 You manage an online store that sells various products. You need to keep track of which
 products are in stock and which are out of stock. Use Python sets to manage this
 inventory.
 Tasks:
 1. Create a set in_stock containing the products 'laptop', 'mouse', 'keyboard', and
 'monitor'.
 2. Create another set out_of_stock containing 'printer' and 'webcam'.
 3. Anewshipment arrives, restocking the 'printer' and adding a new product 'tablet'.
 Update the in_stock set accordingly.
 4. Acustomer reports that the last 'monitor' was sold. Move 'monitor' to the
 out_of_stock set.
 5. Find out which products are either in stock or out of stock, but not both.
 6. Calculate which products are still available for sale
 
'''

in_stock = {'Laptop', 'Keyboard', 'Monitor', 'Mouse'}
out_stock = {'Printer', 'Webcam'}
print(f'Items in stock -> {in_stock}')
print(f'Items out of stock -> {out_stock}')
print()
print('New stock arriving\n')
in_stock.add('Tablet')
in_stock.add('Printer')
out_stock.discard('Printer')
print(f'Items in stock -> {in_stock}')
print(f'Items out of stock -> {out_stock}')
print()
print('Monitor sold')
in_stock.discard('Monitor')
out_stock.add('Monitor')

all_items = in_stock.union(out_stock)

instock = 'In stock'
outstock = 'Out of stock'

print('Item storage')
for index, item in enumerate(all_items, start=1):
    print(f'{index} {item} -> {instock if item in in_stock else outstock}')
