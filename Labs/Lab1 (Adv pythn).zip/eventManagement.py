'''
 Lab 4: Event Management System
 Scenario:
 You are organizing a large event and need to manage the list of attendees. Some
 attendees have VIP access, while others do not.
 Tasks:
 1. Create a set of attendees with names 'John', 'Jane', 'Emily', and 'Michael'.
 2. Create a frozenset vip_attendees with names 'Jane' and 'Michael'.
 3. Anewattendee 'Sarah' registers for the event. Add her to the attendees set.
 4. Check if 'Emily' is a VIP attendee.
 5. Find out which attendees have either regular or VIP access but not both.
 6. List all attendees with either regular or VIP access

'''

attendees = {'John', 'Jane', 'Emily', 'Michel'}
vip_attendees = frozenset(['Jane', 'Michel'])

print('All guests ->', attendees)
print('VIP guests ->', vip_attendees)

attendees.add('Sarah')
print('Added Sarah to the attendees ->', attendees)

print(f"Emily is a VIP attendee -> {True if 'Emily' in vip_attendees else False}")

one_pass_guestes = attendees.symmetric_difference(vip_attendees)
print('Guest with only one pass -> ', one_pass_guestes)

print(f'All attendees with either regular or VIP access -> {attendees.union(vip_attendees)}')