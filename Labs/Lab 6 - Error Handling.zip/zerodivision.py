# 1. Write a Python program to handle a ZeroDivisionError exception when dividing a number by zero.

class CustomZeroDivisionError(Exception):
    def __init__(self, message = 'Division with zero is not allowed'):
        self.message = message
        super().__init__(self.message)

try:
    num1 = int(input('Enter the divisor\n'))
    num2 = int(input('Enter the divident\n'))
    if num2 == 0:
        raise CustomZeroDivisionError()
    print( num1 / num2 )
except CustomZeroDivisionError as CDE:
    print(CDE)

except ValueError:
    print('Invalid value\n')

except Exception:
    print('Exception encountered')


# another simple way

try:
    num1 = int(input('Enter the divisor\n'))
    num2 = int(input('Enter the divident\n'))
    print( num1 / num2 )
except ZeroDivisionError:
    print('Divident can not be zero')

except ValueError:
    print('Invalid value\n')

except Exception:
    print('Exception encountered')

