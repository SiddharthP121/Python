# 2. Write a Python program that prompts the user to input an integer and raises a ValueError exception if the input is not a valid integer.

class CustomValueError(Exception):
    def __init__(self, message = 'Invalid value entered'):
        self.message = message
        super().__init__(self.message)


try:
    num = input('Enter any integer\n')
    try:
        a = int(num)
        print('Integer registered')
    except ValueError or TypeError:
        raise CustomValueError()
    
except CustomValueError as CV:
    print(CV)

except Exception as e:
    print(e)
    print('Exception encountered\n')


# another easy way

    a = input('Enter any integer\n')
    try:
        n = int(a)
    except ValueError:
        print('Invalid value entered')
    except Exception:
        print('Exception encountered')
    else:
        print('Value registered\n')