# 3. Write a Python program that opens a file and handles a FileNotFoundError exception if the file does not exist.


class CustomFileNotFoundError(Exception):
    def __init__(self, message = 'File not found in the system\n'):
        super().__init__(message)

try:
    file = open('data.txt', 'r')
    file.close()
except FileNotFoundError:
    raise CustomFileNotFoundError('Make sure that file exists\n')
except Exception:
    print('Exception encountered\n')


# another way

try:
    file = open('data.txt', 'r')
    file.close()
except FileNotFoundError as e:
    print(f'{e} File not found in the system')
except Exception:
    print('Exception encountered\n')