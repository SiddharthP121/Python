# 4. Write a Python program that prompts the user to input two numbers and raises a TypeError exception if the inputs are not numerical

class CustomTypeError(Exception):
    def __init__(self, message = 'Invalid input provided'):
        super().__init__(message)

try:
    num1 = input('Enter first number\n')
    num2 = input('Enter second number\n')
    try: 
        a = int(num1)
        b = int(num2)
        print('Number registered')
    except TypeError:
        raise CustomTypeError('Invalid value provided\n')
    except ValueError:
        raise CustomTypeError('Invalid value provided\n') 

except Exception as e:
    print(f'{e} Exception encountered')


# another way

try:
    num1 = int(input('Enter first number\n'))
    num2 = int(input('Enter first number\n'))
    print('Number registered\n')
except TypeError as TE:
    print(f'{TE} Invalid values\n')
except ValueError as VE:
    print(f'{VE} Invalid values\n')
except Exception as e:
    print(f'{e} Exception encountered\n')