'''
 3.Write a Python script to read a CSV file and filter out rows based on a specific
 condition (e.g., only rows where the Age is greater than 30). Save the filtered rows
 to a new CSVfile.
 Sample Data (people.csv):
 Name,Age,City
 Alice,30,New York
 Bob,25,Los Angeles
 Charlie,35,Chicago
 Diana,28,Miami

'''

import csv

with open('que3\people.csv', 'r') as file, open('que3\\result.csv', 'a+', newline='') as resultFile:
    csv_data = csv.reader(file)
    header = next(csv_data)
    for index, row in enumerate(csv_data):
        age = int(row[1])
        if age > 30:
            write_csv = csv.writer(resultFile)
            write_csv.writerow(row)

    resultFile.seek(0)
    read_csv = resultFile.read()
    print(read_csv)
    

