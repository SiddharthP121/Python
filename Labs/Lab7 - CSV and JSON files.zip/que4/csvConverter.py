'''
4. Write a Python script to read a JSON file containing an array of objects and
 convert it to a CSV file.
 Sample Data (product.json):
 [
 {"Product ID": 101, "Name": "Widget A", "Price": 25.50},
 {"Product ID": 102, "Name": "Widget B", "Price": 40.00}
 Output (data.csv)
 ]

'''


import csv
import json

with open('que4\product.json', 'r') as json_file, open('que4\product.csv', 'a+', newline='') as csv_file:
    json_data = json.load(json_file)

    headers = json_data[0]
    csv_data = csv.DictWriter(csv_file, fieldnames = headers)
    csv_data.writeheader()
    csv_data.writerows(json_data)
    csv_file.seek(0)
    print(csv_file.read())
    