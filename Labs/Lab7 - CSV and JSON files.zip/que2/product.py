'''
  2. Write a Python script to validate JSON data by checking if it contains required
 fields and if the data types are correct (e.g., integers for IDs, strings for names).
 Sample Data (data.json):
 [
 {
    "Product ID": 101,
    "Name": "Widget A",
    "Price": 25.50
 },
 {
    "Product ID": "102",
    "Name": "Widget B",
    "Price": "40.00
 }
 ]
 
'''

import json

with open('que2/data.json', mode='r') as file:
    data = json.load(file)

for product in data:
    print(f"Product ID: {product['Product ID']}" if type(product['Product ID']) is int else "Invalid product ID")
    print(f"Name: {product['Name']}" if type(product['Name']) is str else "Invalid Product Name")
    print(f"Price: {product['Price']}" if type(product['Price']) is int else "Invalid Product Price")
    print()