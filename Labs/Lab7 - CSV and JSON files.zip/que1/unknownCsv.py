'''
1. Write a Python script to read a CSV file with missing values and replace the
missing values with a default value (e.g., "Unknown" or 0).
Sample Data (missing_data.csv):
Name, Age, City
Alice, , New York
Bob, 25,
Charlie, 35, Chicago
'''

import csv

with open('data.csv', 'r') as file:
    reader = csv.reader(file)
    headers = next(reader)  # ['Name', 'Age', 'City']

    for row in reader:
        # Pad row to match header length
        while len(row) < len(headers):
            row.append("")  # Fill missing fields with empty string

        name = row[0].strip() or "Unknown"
        age = row[1].strip() or "Unknown"
        city = row[2].strip() or "Unknown"

        print(f"{name} {age} {city}")
       