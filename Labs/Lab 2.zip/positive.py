#  3. Python Program to Check if a Number is Positive, Negative or 0

number = int(input("Enter the number to check if it is positive, negative or zero"))

if number > 0 :
    print(f"{number} is a positive number\n")
elif number < 0 :
    print(f"{number} is a negative number\n")
else:
        print(f"{number} is a zero\n")



