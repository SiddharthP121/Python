#  1. Python program to check leap year

year = int(input("Enter any year to check if it is a leap year\n"))

if year % 4 == 0:
    if year % 100 == 0:
        if year % 400 == 0:
            print(f"{year} is a leap year\n")
        else: 
            print(f"{year} is not a leap year\n")
    else: 
        print(f"{year} is a leap year\n")
else:
    print(f"{year} is not a leap year\n")