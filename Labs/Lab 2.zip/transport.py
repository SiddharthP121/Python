# 5. A transport company charges the fare according to following table:
#  Distance                           Charges
#  1-50                           -  8 Rs./Km
#  51-100  -                         10 Rs./Km
# > 100                              12 Rs/K


totalDistance = float(input("Enter the total distance to cover\n"))

if 50 > totalDistance > 0 :
    print(f"The bus fare for {totalDistance} is {totalDistance * 8}")
elif 51 < totalDistance <= 100 :
    after50 = (totalDistance - 50) * 10
    first50 = 50 * 8
    print(f"The bus fare for {totalDistance} is {after50 + first50}")
else :
     after50 = (totalDistance - 50) * 10
     first50 = 50 * 8
     remained = (totalDistance - 100) * 12
     print(f"The bus fare for {totalDistance} is {after50 + first50 + remained}")



    
