# 4. A toy vendor supplies three types of toys: Battery Based Toys, Key-based
#  Toys, and Electrical Charging Based Toys. The vendor gives a discount of
#  10% on orders for battery-based toys if the order is for more than Rs. 1000.
#  On orders of more than Rs. 100 for key-based toys, a discount of 5% is
#  given, and a discount of 10% is given on orders for electrical charging based
#  toys of value more than Rs. 500. Assume that the numeric codes 1,2 and 3
#  are used for battery based toys, key-based toys, and electrical charging based
#  toys respectively. Write a program that reads the product code and the order
#  amount and prints out the net amount that the customer is required to pay
#  after the discount.

productCode = int(input("Press 1 for battery based toy,\n Press 2 for key based toy\n Press 3 for electrical charging based toy\n"))

totalBill = int(input("Enter the total bill\n"))

if productCode == 1 :
    if totalBill > 1000 :
        discount = totalBill * 10 / 100
        totalBill = totalBill - discount
    else :
        totalBill
elif productCode == 2 :
    if totalBill > 100 :
        discount = totalBill * 5 / 100
        totalBill = totalBill - discount
    else :
        totalBill
else :
    if totalBill > 500 :
        discount = totalBill * 10 / 100
        totalBill = totalBill - discount
    else :
        totalBill

print("The total bill is", totalBill)