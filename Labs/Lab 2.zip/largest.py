
#  2. Python Program to Find the Largest Among Three Numbers


num1 = int(input("Enter number 1:\n"))
num2 = int(input("Enter number 2:\n"))
num3 = int(input("Enter number 3:\n"))

if num1 > num2 and num1 > num3:
    print(f"{num1} is the largest number\n")
elif num2 > num1 and num2 > num3:
    print(f"{num2} is the largest number\n")
else:
    print(f"{num3} is the largest number\n")