
# Question 2 	Find the absolute value of a number entered by the user.

num = int(input("Enter the number\n"))

if num<0:
    num = -num
print("The absolute value of the given number is\n",num)