
# Question 1    Any integer is input by the user. Write a program to find out whether it is an odd number or even number.

num = int(input("Please enter the number to check if it is even \n"))
if num%2==0:
    print("Even Number")
else:
    print("Odd Number")    



