'''
 3. You have a list of URLs, and you need to filter out only those that start with 'https'.
 Example Data:
 urls = [
 "http://example.com",
 "https://secure-site.com",
 "ftp://files.example.org",
 "https://another-secure-site.com"
 ]

'''

urls = [
 "http://example.com",
 "https://secure-site.com",
 "ftp://files.example.org",
 "https://another-secure-site.com"
 ]

secure_urls = [url for url in urls if url.startswith('https')]
print(secure_urls)
