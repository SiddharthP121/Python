# 2. Declare two variables and print that which variable is largest using ternary

num1 = 45
num2 = 33

isNum1_Larger = True if num1>num2 else False

print("Number 1 is larger than number 2", isNum1_Larger)