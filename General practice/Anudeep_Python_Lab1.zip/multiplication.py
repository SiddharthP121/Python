#1. Calculate the multiplication and sum of two numbers

firstNumber = int(input("Enter the first number\n"))
secondNumber = int(input("Enter the second number\n"))
RESULT = firstNumber * secondNumber
print("\n", RESULT)