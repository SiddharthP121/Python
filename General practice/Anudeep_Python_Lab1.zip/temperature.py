# 3. Python program to convert the temperature in degree centigrade to Fahrenheit

centigradeTemp = 40
FahrenheitTemp = (centigradeTemp * 9/5) + 32

print("Degree Centigrade temperature:\n", centigradeTemp, "\nConverted Fahrenheit temperature:\n", FahrenheitTemp)
