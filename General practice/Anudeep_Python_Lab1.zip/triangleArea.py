base = float(input("Enter the base of the triangle\n"))
height = float(input("Enter the height of the triangle\n"))

AREA = 1/2 * base * height

print("\n", AREA)