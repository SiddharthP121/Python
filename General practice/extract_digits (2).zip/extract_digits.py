'''
 4. You have a list of strings, and you want to extract all digits from these strings and
 combine them into a single list.
 Example Data:
 strings = [
 "abc123",
 "hello456world",
 "789",
 "test"
 ]

'''

strings = [
 "abc123",
 "hello456world",
 "789",
 "test"
 ]


nums_in_strings = [c for string in strings for c in string if c.isdigit()]
print(nums_in_strings)


